#!/bin/bash

LOGFILE="/tmp/hypr-monitor-setup.log"
echo "[`date`] Monitor script triggered" >> "$LOGFILE"

CONNECTED=$(hyprctl monitors | grep 'Monitor' | awk '{print $2}')

if echo "$CONNECTED" | grep -q 'HDMI-A-1' && echo "$CONNECTED" | grep -q 'DP-1'; then
  echo "Triple monitor setup detected (DP-1, HDMI-A-1, eDP-1)." >> "$LOGFILE"
  
  # DP-1 on the left
  hyprctl keyword monitor DP-1,preferred,0x0,1

  # HDMI-A-1 to the right of DP-1 (assuming 1920x1080 resolution)
  hyprctl keyword monitor HDMI-A-1,preferred,1920x0,1

  # eDP-1 (laptop) below HDMI-A-1
  hyprctl keyword monitor eDP-1,preferred,3840x0,1

  notify-send "Triple monitor layout applied: DP-1 (left), HDMI-A-1 (top), eDP-1 (bottom)"
  
elif echo "$CONNECTED" | grep -q 'HDMI-A-1'; then
  echo "HDMI connected. Setting HDMI as primary." >> "$LOGFILE"
  hyprctl keyword monitor eDP-1,preferred, 0x0,1
  hyprctl keyword monitor HDMI-A-1,preferred,1920x0,1
  notify-send "HDMI connected. Setting HDMI as primary."

else
  echo "Only eDP-1 connected. Setting it as primary." >> "$LOGFILE"
  hyprctl keyword monitor eDP-1,preferred,0x0,1
  notify-send "Only eDP-1 connected. Setting it as primary."
fi

