#!/bin/bash
theme_name="Waybar Starter"
