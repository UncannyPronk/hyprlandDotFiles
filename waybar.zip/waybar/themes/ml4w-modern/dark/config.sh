#!/bin/bash
theme_name="ML4W Modern Dark"
