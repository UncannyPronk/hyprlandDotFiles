#!/bin/bash

# Ensure we're in the correct HOME directory
CONFIG_DIR="$HOME/.config/waybar"

# Kill all existing Waybar instances
pkill waybar 2>/dev/null
sleep 0.5

# Select the correct config
if hyprctl monitors | grep -q 'HDMI-A-1'; then
    echo "HDMI-A-1 detected, using config-hdmi"
    cp "$CONFIG_DIR/config-hdmi" "$CONFIG_DIR/config"
else
    echo "HDMI-A-1 not detected, using config-edp"
    cp "$CONFIG_DIR/config-edp" "$CONFIG_DIR/config"
fi

# Verify the copy worked
echo "Using config:"
cat "$CONFIG_DIR/config"

# Launch Waybar
waybar -c "$CONFIG_DIR/config" -s "$CONFIG_DIR/style.css" &
