#!/bin/bash

# Wait for hyprlock to exit (i.e., unlock)
while pgrep hyprlock > /dev/null; do
    sleep 0.03
done

# Restart Waybar to trigger animations
pkill waybar
$HOME/.config/waybar/launch.sh &

exit 0

